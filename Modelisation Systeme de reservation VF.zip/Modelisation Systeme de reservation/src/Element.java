import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("95597214-bf3e-4df5-a5a8-9ea52299d9c9")
public class Element {
    @objid ("bfd4a3fa-a58f-4f56-8ec5-4ef36cb3709f")
    private String nom;

    @objid ("5c02dbec-978b-42ec-9008-f6d6172acdd9")
    private int capacite;

    @objid ("d3de9924-435f-412b-a6df-da64cd8f97b2")
    private double prix;

    @objid ("aaea5702-e06a-435c-8b5b-453c39343955")
    private String type;

    @objid ("6846fd8e-a171-40ef-928e-a2f9fff5ea73")
    public String getNom() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.nom;
    }

    @objid ("f938a08d-0e70-4eae-a115-30bf7add9e86")
    public void setNom(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.nom = value;
    }

    @objid ("e1a2dded-307e-4cbd-a95a-78829887c081")
    public int getCapacite() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.capacite;
    }

    @objid ("037106f8-f44a-4368-8cfe-68474a3a697d")
    public void setCapacite(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.capacite = value;
    }

    @objid ("54665dee-d69c-4c27-8018-4e240704df5e")
    public double getPrix() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.prix;
    }

    @objid ("27c6bc79-acb3-4d30-a9e1-f13ba0b3c160")
    public void setPrix(final double value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.prix = value;
    }

    @objid ("6b417be9-04b6-41a8-9049-b3f6b1ab90a5")
    public String getType() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.type;
    }

    @objid ("13cd5859-38ab-45ad-b845-fbe439263976")
    public void setType(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.type = value;
    }

}

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6c79f684-97d8-4807-9d92-ea2e4451ee3a")
public class Avis {
    @objid ("cb93fb23-ebe2-4cc9-9eb1-ed4ec84b7935")
    private String avis;

    @objid ("520174e3-f865-415a-bd38-deda901b50cd")
    public String getAvis() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.avis;
    }

    @objid ("477aa25f-9879-4be4-a334-2dbc90e161c7")
    public void setAvis(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.avis = value;
    }

}
